<?php


td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newspaper_6/entertainment/9.jpg");

//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/entertainment/p1.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/entertainment/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      'http://demo_content.tagdiv.com/Newspaper_6/entertainment/logo-header@2x.png');