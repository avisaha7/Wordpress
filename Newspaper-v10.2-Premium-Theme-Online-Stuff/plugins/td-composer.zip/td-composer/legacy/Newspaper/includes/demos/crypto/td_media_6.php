<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo',                     "http://demo_content.tagdiv.com/Newspaper_6/crypto/logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_retina',              "http://demo_content.tagdiv.com/Newspaper_6/crypto/logo-retina.png");