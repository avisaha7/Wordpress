<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/np10blue.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/np10blue-retina.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/np10blue-white-retina.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/mobile-bg.jpg');

