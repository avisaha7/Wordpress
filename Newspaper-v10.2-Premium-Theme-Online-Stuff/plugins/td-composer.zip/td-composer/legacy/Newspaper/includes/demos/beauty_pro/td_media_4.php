<?php
// magazine imgs
td_demo_media::add_image_to_media_gallery('td_magazine1',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine1.jpg");
td_demo_media::add_image_to_media_gallery('td_magazine2',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine2.jpg");
td_demo_media::add_image_to_media_gallery('td_magazine3',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine3.jpg");
td_demo_media::add_image_to_media_gallery('td_magazine4',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine4.jpg");
td_demo_media::add_image_to_media_gallery('td_magazine5',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine5.jpg");
td_demo_media::add_image_to_media_gallery('td_magazine6',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine6.jpg");