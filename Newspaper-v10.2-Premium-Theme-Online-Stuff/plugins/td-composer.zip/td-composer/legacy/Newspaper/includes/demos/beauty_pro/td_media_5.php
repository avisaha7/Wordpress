<?php

//404 image
td_demo_media::add_image_to_media_gallery('td_pic_404',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/404.jpg");

//category bg
td_demo_media::add_image_to_media_gallery('td_category_bg',                "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/cat-bg.jpg");

//logo bg
td_demo_media::add_image_to_media_gallery('td_logo_bg',                    "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/logo-bg.jpg");

//mobile & login bg
td_demo_media::add_image_to_media_gallery('td_login_bg',                  "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/login-bg.jpg");
td_demo_media::add_image_to_media_gallery('td_mobile_bg',                  "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/mobile-bg.jpg");