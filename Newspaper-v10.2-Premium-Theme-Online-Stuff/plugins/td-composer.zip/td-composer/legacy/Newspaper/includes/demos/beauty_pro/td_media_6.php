<?php

// ads
td_demo_media::add_image_to_media_gallery('td_reclama1',                   "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/reclama1.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama2',                   "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/reclama2.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama_long',               "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/reclama-long.jpg");

//magazine imgs
td_demo_media::add_image_to_media_gallery('td_magazine_author',            "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine-author.jpg");
td_demo_media::add_image_to_media_gallery('td_magazine_bg',                "http://demo_content.tagdiv.com/Newspaper_6/fashion_pro/magazine-bg.jpg");

