<?php
/**
 * Created by ra on 6/13/2015.
 */
//ads
td_demo_media::add_image_to_media_gallery('td_blog_full_ad',            "http://demo_content.tagdiv.com/Newspaper_6/blog/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_blog_sidebar_ad',         "http://demo_content.tagdiv.com/Newspaper_6/blog/rec300.jpg");

