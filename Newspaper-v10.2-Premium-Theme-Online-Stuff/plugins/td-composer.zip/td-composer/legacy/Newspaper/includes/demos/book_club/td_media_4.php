<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_13',                  "http://demo_content.tagdiv.com/Newspaper_6/book_club/13.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_14',                  "http://demo_content.tagdiv.com/Newspaper_6/book_club/14.jpg");
//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/book_club/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_6/book_club/p2.jpg");


