<?php
td_demo_media::add_image_to_media_gallery('td_pic_13', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/13.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_14', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/14.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_15', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/15.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_16', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/16.jpg');

